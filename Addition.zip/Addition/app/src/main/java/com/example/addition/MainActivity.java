package com.example.addition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private EditText FirstNumber;
private EditText SecondNumber;
private Button Addition;
private TextView Result;


    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirstNumber=(EditText) findViewById(R.id.num1);
        SecondNumber=(EditText) findViewById(R.id.num2);
        Addition=(Button) findViewById(R.id.addbutton);
        Result=(TextView) findViewById(R.id.textView3);

        Addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1=Integer.parseInt(FirstNumber.getText().toString());
                int number2=Integer.parseInt(SecondNumber.getText().toString());
                int Output=number1+number2;

                Result.setText(Output+"");
            }
        });

    }
}