package com.example.practical8part3;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private TextView sensorListTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the sensor manager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Get the text view for displaying the sensor list
        sensorListTextView = findViewById(R.id.sensor_list_text_view);

        // Get the list of sensors
        List<Sensor> sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL);

        // Display the list of sensors in the text view
        StringBuilder sensorListStringBuilder = new StringBuilder();
        for (Sensor sensor : sensorList) {
            sensorListStringBuilder.append(sensor.getName()).append("\n");
        }
        sensorListTextView.setText(sensorListStringBuilder.toString());
    }
}
