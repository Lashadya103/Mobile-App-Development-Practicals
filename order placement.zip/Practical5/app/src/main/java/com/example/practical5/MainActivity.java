package com.example.practical5;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.Toast;
        import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    CheckBox pizza,coffee,burger;
    Button buttonOrder;

    private ImageView logoIV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButtonClick();

        logoIV = findViewById(R.id.idIVLogo);

        logoIV.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }
    public void addListenerOnButtonClick(){
        //Getting instance of CheckBoxes and Button from the activty_main.xml file
        pizza=(CheckBox)findViewById(R.id.checkBox);
        coffee=(CheckBox)findViewById(R.id.checkBox3);
        burger=(CheckBox)findViewById(R.id.checkBox4);
        buttonOrder=(Button)findViewById(R.id.button);

        //Applying the Listener on the Button click
        buttonOrder.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                int totalamount=0;
                StringBuilder result=new StringBuilder();
                result.append("Selected Items:");
                if(pizza.isChecked()){
                    result.append("\nPizza 1500Rs");
                    totalamount+=1500;
                }
                if(coffee.isChecked()){
                    result.append("\nCoffee 150Rs");
                    totalamount+=150;
                }
                if(burger.isChecked()){
                    result.append("\nBurger 220Rs");
                    totalamount+=220;
                }
                result.append("\nTotal: "+totalamount+"Rs");
                //Displaying the message on the toast
                Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
            }

   });
}
}
