package com.example.firebase;

public class Book {
    private String ISBNNo,name,author,publisher;

    public String getISBNNo() {
        return ISBNNo;
    }

    public void setISBNNo(String ISBNNo) {
        this.ISBNNo = ISBNNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

}
